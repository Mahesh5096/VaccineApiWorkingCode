const vaccineUrl =`https://cdn-api.co-vin.in/api/v2/appointment/sessions/public/calendarByPin?pincode=600081&date=20-08-2021`;
export{vaccineUrl};